import { base44 } from './base44Client';


export const Buyer = base44.entities.Buyer;

export const LentilInventory = base44.entities.LentilInventory;

export const Campaign = base44.entities.Campaign;

export const Response = base44.entities.Response;

export const AppSettings = base44.entities.AppSettings;



// auth sdk:
export const User = base44.auth;