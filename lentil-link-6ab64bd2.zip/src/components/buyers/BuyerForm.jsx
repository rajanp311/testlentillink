import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus, UserPlus } from "lucide-react";

const LENTIL_TYPES = [
  "Red Lentils",
  "Green Lentils", 
  "Brown Lentils",
  "Black Lentils",
  "Yellow Lentils",
  "Masoor Dal",
  "Moong Dal",
  "Chana Dal",
  "Toor Dal",
  "Urad Dal"
];

export default function BuyerForm({ buyer, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    name: buyer?.name || "",
    phone: buyer?.phone || "",
    business_name: buyer?.business_name || "",
    location: buyer?.location || "",
    country: buyer?.country || "",
    currency: buyer?.currency || "AED",
    preferred_lentils: buyer?.preferred_lentils || [],
    status: buyer?.status || "active",
    notes: buyer?.notes || ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addPreferredLentil = (lentil) => {
    if (!formData.preferred_lentils.includes(lentil)) {
      setFormData(prev => ({
        ...prev,
        preferred_lentils: [...prev.preferred_lentils, lentil]
      }));
    }
  };

  const removePreferredLentil = (lentil) => {
    setFormData(prev => ({
      ...prev,
      preferred_lentils: prev.preferred_lentils.filter(l => l !== lentil)
    }));
  };

  return (
    <Card className="mb-6 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserPlus className="w-5 h-5" />
          {buyer ? "Edit Buyer" : "Add New Buyer"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Enter buyer's full name"
                required
              />
            </div>
            <div>
              <Label htmlFor="phone">WhatsApp Phone *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                placeholder="+971501234567"
                required
              />
            </div>
            <div>
              <Label htmlFor="business_name">Business Name</Label>
              <Input
                id="business_name"
                value={formData.business_name}
                onChange={(e) => handleInputChange("business_name", e.target.value)}
                placeholder="Business or company name"
              />
            </div>
            <div>
              <Label htmlFor="location">City</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
                placeholder="City"
              />
            </div>
            <div>
              <Label htmlFor="country">Country</Label>
              <Input
                id="country"
                value={formData.country}
                onChange={(e) => handleInputChange("country", e.target.value)}
                placeholder="e.g., UAE, India"
              />
            </div>
            <div>
              <Label htmlFor="currency">Local Currency</Label>
              <Select value={formData.currency} onValueChange={(value) => handleInputChange("currency", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AED">AED (UAE Dirham)</SelectItem>
                  <SelectItem value="INR">INR (Indian Rupee)</SelectItem>
                  <SelectItem value="TRY">TRY (Turkish Lira)</SelectItem>
                  <SelectItem value="USD">USD (US Dollar)</SelectItem>
                  <SelectItem value="KES">KES (Kenyan Shilling)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="blocked">Blocked</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Preferred Lentils</Label>
            <div className="mt-2 space-y-3">
              <Select onValueChange={addPreferredLentil}>
                <SelectTrigger>
                  <SelectValue placeholder="Add preferred lentil types" />
                </SelectTrigger>
                <SelectContent>
                  {LENTIL_TYPES.filter(lentil => !formData.preferred_lentils.includes(lentil)).map((lentil) => (
                    <SelectItem key={lentil} value={lentil}>{lentil}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {formData.preferred_lentils.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {formData.preferred_lentils.map((lentil) => (
                    <Badge key={lentil} variant="secondary" className="flex items-center gap-1">
                      {lentil}
                      <button
                        type="button"
                        onClick={() => removePreferredLentil(lentil)}
                        className="hover:text-red-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleInputChange("notes", e.target.value)}
              placeholder="Additional notes about this buyer..."
              rows={3}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              {buyer ? "Update Buyer" : "Add Buyer"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}