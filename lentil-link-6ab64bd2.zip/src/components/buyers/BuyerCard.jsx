import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, MapPin, Building2, Edit2, Trash2, Clock } from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  active: "bg-green-100 text-green-800",
  inactive: "bg-orange-100 text-orange-800",
  blocked: "bg-red-100 text-red-800"
};

export default function BuyerCard({ buyer, onEdit, onDelete }) {
  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-gray-900 mb-1">{buyer.name}</h3>
            <div className="flex items-center gap-2 mb-2">
              <Badge className={statusColors[buyer.status]}>
                {buyer.status}
              </Badge>
              {buyer.business_name && (
                <span className="text-sm text-gray-600">• {buyer.business_name}</span>
              )}
            </div>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit(buyer)}
              className="h-8 w-8 hover:bg-green-50 hover:text-green-600"
            >
              <Edit2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(buyer.id)}
              className="h-8 w-8 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm">
            <Phone className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">{buyer.phone}</span>
          </div>
          
          {buyer.location && (
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600">{buyer.location}</span>
            </div>
          )}

          {buyer.preferred_lentils && buyer.preferred_lentils.length > 0 && (
            <div className="space-y-1">
              <p className="text-sm text-gray-500">Preferred Lentils:</p>
              <div className="flex flex-wrap gap-1">
                {buyer.preferred_lentils.slice(0, 3).map((lentil) => (
                  <Badge key={lentil} variant="outline" className="text-xs">
                    {lentil}
                  </Badge>
                ))}
                {buyer.preferred_lentils.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{buyer.preferred_lentils.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}

          {buyer.last_contacted && (
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <Clock className="w-3 h-3" />
              Last contacted: {format(new Date(buyer.last_contacted), 'MMM d, yyyy')}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}