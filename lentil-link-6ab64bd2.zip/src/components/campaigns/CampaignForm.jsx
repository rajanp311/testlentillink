
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { MessageSquare, Clock, Users, X } from "lucide-react";

export default function CampaignForm({ campaign, buyers, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    name: campaign?.name || "",
    message_template: campaign?.message_template || "",
    scheduled_time: campaign?.scheduled_time || "09:00",
    target_buyers: campaign?.target_buyers || [],
    status: campaign?.status || "active"
  });

  const [selectAll, setSelectAll] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleBuyerToggle = (buyerId) => {
    setFormData(prev => ({
      ...prev,
      target_buyers: prev.target_buyers.includes(buyerId)
        ? prev.target_buyers.filter(id => id !== buyerId)
        : [...prev.target_buyers, buyerId]
    }));
  };

  const handleSelectAll = (checked) => {
    setSelectAll(checked);
    if (checked) {
      setFormData(prev => ({
        ...prev,
        target_buyers: buyers.filter(buyer => buyer.status === 'active').map(buyer => buyer.id)
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        target_buyers: []
      }));
    }
  };

  const getSelectedBuyers = () => {
    return buyers.filter(buyer => formData.target_buyers.includes(buyer.id));
  };

  return (
    <Card className="mb-6 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5" />
          {campaign ? "Edit Campaign" : "Create New Campaign"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Campaign Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="e.g., Daily Lentil Inquiry"
                required
              />
            </div>
            <div>
              <Label htmlFor="scheduled_time">Scheduled Time *</Label>
              <Input
                id="scheduled_time"
                type="time"
                value={formData.scheduled_time}
                onChange={(e) => handleInputChange("scheduled_time", e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="paused">Paused</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="message_template">Message Template *</Label>
            <Textarea
              id="message_template"
              value={formData.message_template}
              onChange={(e) => handleInputChange("message_template", e.target.value)}
              placeholder="Hello {buyer_name}! Today's price for Red Lentils is 3.50 AED/kg. What can I get for you?"
              rows={4}
              required
            />
            <p className="text-sm text-gray-500 mt-1">
              Use {"{buyer_name}"} to personalize messages with buyer names
            </p>
          </div>

          <div>
            <Label>Target Buyers</Label>
            <div className="mt-2 space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="select-all"
                  checked={selectAll}
                  onCheckedChange={handleSelectAll}
                />
                <Label htmlFor="select-all" className="text-sm">
                  Select all active buyers ({buyers.filter(b => b.status === 'active').length})
                </Label>
              </div>

              <div className="max-h-48 overflow-y-auto border rounded-lg p-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {buyers.filter(buyer => buyer.status === 'active').map((buyer) => (
                    <div key={buyer.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={buyer.id}
                        checked={formData.target_buyers.includes(buyer.id)}
                        onCheckedChange={() => handleBuyerToggle(buyer.id)}
                      />
                      <Label htmlFor={buyer.id} className="text-sm">
                        {buyer.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {formData.target_buyers.length > 0 && (
                <div className="mt-3">
                  <p className="text-sm text-gray-600 mb-2">Selected buyers ({formData.target_buyers.length}):</p>
                  <div className="flex flex-wrap gap-2">
                    {getSelectedBuyers().slice(0, 10).map((buyer) => (
                      <Badge key={buyer.id} variant="secondary" className="flex items-center gap-1">
                        {buyer.name}
                        <button
                          type="button"
                          onClick={() => handleBuyerToggle(buyer.id)}
                          className="hover:text-red-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                    {getSelectedBuyers().length > 10 && (
                      <Badge variant="outline">
                        +{getSelectedBuyers().length - 10} more
                      </Badge>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              {campaign ? "Update Campaign" : "Create Campaign"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
