import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, Clock, Users, Edit2, Trash2, Play, Pause, Send } from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  active: "bg-green-100 text-green-800",
  paused: "bg-orange-100 text-orange-800",
  completed: "bg-blue-100 text-blue-800"
};

export default function CampaignCard({ campaign, buyers, onEdit, onDelete, onStatusToggle }) {
  const getResponseRate = () => {
    if (!campaign.total_sent || campaign.total_sent === 0) return 0;
    return ((campaign.total_responses / campaign.total_sent) * 100).toFixed(1);
  };

  const getTargetBuyersCount = () => {
    return campaign.target_buyers?.length || 0;
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-lg text-gray-900">{campaign.name}</h3>
              <Badge className={statusColors[campaign.status]}>
                {campaign.status}
              </Badge>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {campaign.scheduled_time}
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                {getTargetBuyersCount()} buyers
              </div>
            </div>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onStatusToggle(campaign)}
              className="h-8 w-8 hover:bg-blue-50 hover:text-blue-600"
            >
              {campaign.status === 'active' ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit(campaign)}
              className="h-8 w-8 hover:bg-green-50 hover:text-green-600"
            >
              <Edit2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(campaign.id)}
              className="h-8 w-8 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-4">
          <div className="bg-gray-50 p-3 rounded-lg">
            <p className="text-sm text-gray-700 line-clamp-3">
              {campaign.message_template}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-lg font-bold text-gray-900">{campaign.total_sent || 0}</div>
              <div className="text-xs text-gray-500">Sent</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-green-600">{campaign.total_responses || 0}</div>
              <div className="text-xs text-gray-500">Responses</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-blue-600">{getResponseRate()}%</div>
              <div className="text-xs text-gray-500">Rate</div>
            </div>
          </div>

          {campaign.last_sent && (
            <div className="text-xs text-gray-500">
              Last sent: {format(new Date(campaign.last_sent), 'MMM d, yyyy HH:mm')}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}