import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageSquare, Send, TrendingUp, Users } from "lucide-react";

export default function CampaignStats({ campaigns, statusStats, totalStats }) {
  const responseRate = totalStats.totalSent > 0 
    ? ((totalStats.totalResponses / totalStats.totalSent) * 100).toFixed(1)
    : 0;

  const stats = [
    {
      title: "Total Campaigns",
      value: campaigns.length,
      icon: MessageSquare,
      color: "blue",
      trend: `${statusStats.active || 0} active`
    },
    {
      title: "Messages Sent",
      value: totalStats.totalSent,
      icon: Send,
      color: "green",
      trend: "all time"
    },
    {
      title: "Total Responses",
      value: totalStats.totalResponses,
      icon: Users,
      color: "purple",
      trend: "received"
    },
    {
      title: "Response Rate",
      value: `${responseRate}%`,
      icon: TrendingUp,
      color: "orange",
      trend: "average"
    }
  ];

  const colorClasses = {
    blue: { bg: "bg-blue-500", text: "text-blue-600", bgLight: "bg-blue-50" },
    green: { bg: "bg-green-500", text: "text-green-600", bgLight: "bg-green-50" },
    purple: { bg: "bg-purple-500", text: "text-purple-600", bgLight: "bg-purple-50" },
    orange: { bg: "bg-orange-500", text: "text-orange-600", bgLight: "bg-orange-50" }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {stats.map((stat, index) => {
        const colors = colorClasses[stat.color];
        return (
          <Card key={index} className="bg-white/80 backdrop-blur-sm shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${colors.bgLight}`}>
                  <stat.icon className={`w-5 h-5 ${colors.text}`} />
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.title}</p>
                </div>
              </div>
              <p className="text-xs text-gray-500">{stat.trend}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}