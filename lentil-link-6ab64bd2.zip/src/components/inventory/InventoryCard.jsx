import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, MapPin, Edit2, Trash2, AlertTriangle } from "lucide-react";
import { format } from "date-fns";

const gradeColors = {
  premium: "bg-purple-100 text-purple-800",
  standard: "bg-blue-100 text-blue-800",
  basic: "bg-gray-100 text-gray-800"
};

const AED_TO_CAD_RATE = 0.37; // Approximate conversion rate

export default function InventoryCard({ item, onEdit, onDelete, displayCurrency, conversionRate }) {
  const isLowStock = item.stock_quantity < 100;
  
  const priceInSelectedCurrency = item.current_price * (conversionRate || 1);

  return (
    <Card className={`bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 group ${
      isLowStock ? 'border-orange-200' : ''
    }`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-lg text-gray-900">{item.name}</h3>
              {isLowStock && (
                <AlertTriangle className="w-4 h-4 text-orange-500" />
              )}
            </div>
            <p className="text-sm text-gray-600 mb-2">{item.variety}</p>
            <div className="flex items-center gap-2 mb-2">
              <Badge className={gradeColors[item.quality_grade]}>
                {item.quality_grade}
              </Badge>
              <Badge variant="outline" className={isLowStock ? 'border-orange-300 text-orange-700' : ''}>
                {item.stock_quantity} {item.unit}
              </Badge>
            </div>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit(item)}
              className="h-8 w-8 hover:bg-green-50 hover:text-green-600"
            >
              <Edit2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(item.id)}
              className="h-8 w-8 hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="bg-green-50 p-3 rounded-lg">
            <div className="flex justify-between items-baseline">
                <div>
                    <p className="text-2xl font-bold text-green-700">{displayCurrency} {priceInSelectedCurrency.toFixed(2)}</p>
                    <p className="text-sm text-gray-600">per {item.unit}</p>
                </div>
                <div className="text-right">
                    <p className="text-md font-semibold text-blue-600">CAD {(item.current_price * AED_TO_CAD_RATE).toFixed(2)}</p>
                    <p className="text-xs text-gray-500">approx.</p>
                </div>
            </div>
          </div>
          
          {item.origin && (
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600">{item.origin}</span>
            </div>
          )}

          {item.minimum_order && (
            <div className="text-sm text-gray-600">
              Min. Order: {item.minimum_order} {item.unit}
            </div>
          )}

          {item.description && (
            <p className="text-sm text-gray-600 line-clamp-2">{item.description}</p>
          )}

          {item.last_updated && (
            <div className="text-xs text-gray-500">
              Updated: {format(new Date(item.last_updated), 'MMM d, yyyy')}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}