
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, DollarSign, AlertTriangle, TrendingUp } from "lucide-react";

export default function InventoryStats({ inventory, lowStockCount, totalValue }) {
  const averagePrice = inventory.length > 0 
    ? inventory.reduce((sum, item) => sum + item.current_price, 0) / inventory.length 
    : 0;

  const totalStock = inventory.reduce((sum, item) => sum + item.stock_quantity, 0);

  const stats = [
    {
      title: "Total Items",
      value: inventory.length,
      icon: Package,
      color: "blue",
      trend: "items in stock"
    },
    {
      title: "Total Value",
      value: `AED ${totalValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`,
      icon: DollarSign,
      color: "green",
      trend: "inventory value"
    },
    {
      title: "Average Price",
      value: `AED ${averagePrice.toFixed(2)}`,
      icon: TrendingUp,
      color: "purple",
      trend: "per kg"
    },
    {
      title: "Low Stock Items",
      value: lowStockCount,
      icon: AlertTriangle,
      color: lowStockCount > 0 ? "orange" : "green",
      trend: lowStockCount > 0 ? "need restocking" : "all good"
    }
  ];

  const colorClasses = {
    blue: { bg: "bg-blue-500", text: "text-blue-600", bgLight: "bg-blue-50" },
    green: { bg: "bg-green-500", text: "text-green-600", bgLight: "bg-green-50" },
    purple: { bg: "bg-purple-500", text: "text-purple-600", bgLight: "bg-purple-50" },
    orange: { bg: "bg-orange-500", text: "text-orange-600", bgLight: "bg-orange-50" }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {stats.map((stat, index) => {
        const colors = colorClasses[stat.color];
        return (
          <Card key={index} className="bg-white/80 backdrop-blur-sm shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${colors.bgLight}`}>
                  <stat.icon className={`w-5 h-5 ${colors.text}`} />
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.title}</p>
                </div>
              </div>
              <p className="text-xs text-gray-500">{stat.trend}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
