import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

const colorClasses = {
  green: { bg: "bg-green-500", text: "text-green-600", bgLight: "bg-green-50" },
  blue: { bg: "bg-blue-500", text: "text-blue-600", bgLight: "bg-blue-50" },
  purple: { bg: "bg-purple-500", text: "text-purple-600", bgLight: "bg-purple-50" },
  orange: { bg: "bg-orange-500", text: "text-orange-600", bgLight: "bg-orange-50" }
};

export default function MetricCard({ title, value, icon: Icon, color, trend }) {
  const colors = colorClasses[color] || colorClasses.green;

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-lg ${colors.bgLight}`}>
            <Icon className={`w-5 h-5 ${colors.text}`} />
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-gray-900">{value}</p>
            <p className="text-sm text-gray-600">{title}</p>
          </div>
        </div>
        {trend && (
          <div className="flex items-center gap-1 text-sm">
            <TrendingUp className="w-3 h-3 text-green-500" />
            <span className="text-gray-600">{trend}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}