import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Users, Package, MessageSquare, BarChart3, Plus } from "lucide-react";

export default function QuickActions() {
  const actions = [
    {
      title: "Add New Buyer",
      description: "Add a new buyer to your contact list",
      icon: Users,
      href: createPageUrl("Buyers"),
      color: "bg-green-500"
    },
    {
      title: "Update Inventory",
      description: "Add or update lentil prices",
      icon: Package,
      href: createPageUrl("Inventory"),
      color: "bg-blue-500"
    },
    {
      title: "Create Campaign",
      description: "Set up a new WhatsApp campaign",
      icon: MessageSquare,
      href: createPageUrl("Campaigns"),
      color: "bg-purple-500"
    },
    {
      title: "View Analytics",
      description: "Check your bot performance",
      icon: BarChart3,
      href: createPageUrl("Analytics"),
      color: "bg-orange-500"
    }
  ];

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-3">
          {actions.map((action) => (
            <Link key={action.title} to={action.href}>
              <Button
                variant="outline"
                className="w-full justify-start h-auto p-4 hover:bg-gray-50"
              >
                <div className={`w-8 h-8 rounded-lg ${action.color} flex items-center justify-center mr-3`}>
                  <action.icon className="w-4 h-4 text-white" />
                </div>
                <div className="text-left">
                  <div className="font-medium text-gray-900">{action.title}</div>
                  <div className="text-sm text-gray-500">{action.description}</div>
                </div>
              </Button>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}