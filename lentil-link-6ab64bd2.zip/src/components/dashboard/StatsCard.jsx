import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

const colorClasses = {
  green: {
    bg: "bg-green-500",
    text: "text-green-600",
    bgLight: "bg-green-50"
  },
  blue: {
    bg: "bg-blue-500", 
    text: "text-blue-600",
    bgLight: "bg-blue-50"
  },
  purple: {
    bg: "bg-purple-500",
    text: "text-purple-600", 
    bgLight: "bg-purple-50"
  },
  orange: {
    bg: "bg-orange-500",
    text: "text-orange-600",
    bgLight: "bg-orange-50"
  }
};

export default function StatsCard({ title, value, total, icon: Icon, color, trend }) {
  const colors = colorClasses[color] || colorClasses.green;
  
  return (
    <Card className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm">
      <div className={`absolute top-0 right-0 w-32 h-32 ${colors.bgLight} rounded-full opacity-30 transform translate-x-8 -translate-y-8`} />
      
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
          <div className={`p-2 rounded-lg ${colors.bgLight}`}>
            <Icon className={`w-4 h-4 ${colors.text}`} />
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-2">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-gray-900">{value}</span>
            {total && (
              <span className="text-sm text-gray-500">/ {total}</span>
            )}
          </div>
          
          {trend && (
            <div className="flex items-center gap-1 text-sm">
              <TrendingUp className="w-3 h-3 text-green-500" />
              <span className="text-gray-600">{trend}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}