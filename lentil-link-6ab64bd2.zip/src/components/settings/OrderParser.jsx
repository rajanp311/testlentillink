import React, { useState } from "react";
import { InvokeLLM } from "@/api/integrations";
import { Buyer, Response } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const orderSchema = {
  type: "object",
  properties: {
    buyer: {
      type: "object",
      properties: {
        name: { type: "string" },
        company: { type: "string" },
        phone: { type: "string" },
      },
    },
    order: {
      type: "object",
      properties: {
        items: {
          type: "array",
          items: {
            type: "object",
            properties: {
              product: { type: "string" },
              quantity: { type: "number" },
              unit: { type: "string" },
              unit_price: { type: "number" },
              total_price: { type: "number" },
            },
          },
        },
        total_value: { type: "number" },
        currency: { type: "string", default: "USD" },
        shipping_terms: { type: "string" },
        packaging: { type: "string" },
        shipping_date: { type: "string", format: "date" },
      },
    },
  },
};

export default function OrderParser() {
  const [message, setMessage] = useState("");
  const [isParsing, setIsParsing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [parsedData, setParsedData] = useState(null);

  const handleParse = async () => {
    if (!message) return;
    setIsParsing(true);
    setParsedData(null);
    try {
      const result = await InvokeLLM({
        prompt: `You are an intelligent order processing assistant for a lentil commodity trader. Parse the following text from a WhatsApp message and extract the order details into a structured JSON format. Identify the buyer's name, company, phone number, and each line item with product name, quantity, unit, unit price, and total price. Also extract shipping terms, packaging requirements, and preferred shipping date. The base currency is USD unless otherwise specified.

Message to parse:
---
${message}
---`,
        response_json_schema: orderSchema,
      });
      setParsedData(result);
    } catch (error) {
      console.error("Error parsing message:", error);
      toast({
        title: "Parsing Error",
        description: "Could not parse the message. Please try again or reformat.",
        variant: "destructive",
      });
    } finally {
      setIsParsing(false);
    }
  };

  const handleSave = async () => {
    if (!parsedData) return;
    setIsSaving(true);
    try {
        // 1. Find or create buyer
        let buyerRecord;
        const existingBuyers = await Buyer.filter({ phone: parsedData.buyer.phone });
        if (existingBuyers.length > 0) {
            buyerRecord = existingBuyers[0];
        } else {
            buyerRecord = await Buyer.create({
                name: parsedData.buyer.name,
                business_name: parsedData.buyer.company,
                phone: parsedData.buyer.phone,
                status: 'active'
            });
        }

        // 2. Create Response (Order) record
        await Response.create({
            buyer_id: buyerRecord.id,
            response_content: message,
            requested_lentils: parsedData.order.items.map(item => ({
                lentil_name: item.product,
                quantity: item.quantity,
                unit: item.unit,
                unit_price: item.unit_price,
                total_price: item.total_price
            })),
            total_order_value: parsedData.order.total_value,
            order_currency: parsedData.order.currency,
            shipping_terms: parsedData.order.shipping_terms,
            packaging: parsedData.order.packaging,
            preferred_shipping_date: parsedData.order.shipping_date,
            status: 'order_placed',
            response_date: new Date().toISOString()
        });

      toast({
        title: "Success!",
        description: "Order has been saved successfully.",
      });
      setParsedData(null);
      setMessage("");
    } catch (error) {
      console.error("Error saving order:", error);
      toast({
        title: "Saving Error",
        description: "Could not save the order.",
        variant: "destructive",
      });
    } finally {
        setIsSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <Textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Paste the full order message from WhatsApp here..."
        rows={10}
      />
      <Button onClick={handleParse} disabled={isParsing || !message}>
        {isParsing ? "Parsing..." : "Parse Message"}
      </Button>

      {parsedData && (
        <Card className="bg-gray-50">
          <CardContent className="p-4 space-y-4">
            <h3 className="font-semibold">Parsed Order Details (Review before saving)</h3>
            <div className="space-y-2">
                <p><strong>Buyer:</strong> {parsedData.buyer.name} ({parsedData.buyer.company})</p>
                <p><strong>Phone:</strong> {parsedData.buyer.phone}</p>
                <p><strong>Shipping:</strong> {parsedData.order.shipping_terms}</p>
                <p><strong>Packaging:</strong> {parsedData.order.packaging}</p>
                <p><strong>Total Value:</strong> {parsedData.order.total_value} {parsedData.order.currency}</p>
            </div>
            <div>
                <h4 className="font-medium mb-2">Items:</h4>
                <div className="flex flex-wrap gap-2">
                    {parsedData.order.items.map((item, index) => (
                        <Badge key={index} variant="secondary">{item.quantity} {item.unit} of {item.product}</Badge>
                    ))}
                </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving ? "Saving..." : "Confirm and Save Order"}
              </Button>
              <Button variant="outline" onClick={() => setParsedData(null)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}