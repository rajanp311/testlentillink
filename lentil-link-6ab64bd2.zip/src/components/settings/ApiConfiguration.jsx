import React, { useState, useEffect } from "react";
import { AppSettings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

export default function ApiConfiguration() {
  const [settings, setSettings] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const existingSettings = await AppSettings.filter({ singleton: "singleton" });
      if (existingSettings.length > 0) {
        setSettings(existingSettings[0]);
      } else {
        setSettings({ whatsappApiKey: "", whatsappApiSecret: "" });
      }
    } catch (error) {
      console.error("Error loading settings:", error);
      toast({
        title: "Error",
        description: "Could not load settings.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      if (settings.id) {
        await AppSettings.update(settings.id, settings);
      } else {
        await AppSettings.create({ ...settings, singleton: "singleton" });
      }
      toast({
        title: "Success!",
        description: "API settings have been saved.",
      });
      loadSettings();
    } catch (error) {
      console.error("Error saving settings:", error);
      toast({
        title: "Error",
        description: "Could not save settings.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-1/4" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-8 w-1/4" />
        <Skeleton className="h-10 w-full" />
      </div>
    );
  }

  return (
    <form onSubmit={handleSave} className="space-y-4">
      <div>
        <Label htmlFor="apiKey">WhatsApp API Key</Label>
        <Input
          id="apiKey"
          type="password"
          value={settings?.whatsappApiKey || ""}
          onChange={(e) => setSettings({ ...settings, whatsappApiKey: e.target.value })}
          placeholder="Enter your WhatsApp API Key"
        />
      </div>
      <div>
        <Label htmlFor="apiSecret">WhatsApp API Secret</Label>
        <Input
          id="apiSecret"
          type="password"
          value={settings?.whatsappApiSecret || ""}
          onChange={(e) => setSettings({ ...settings, whatsappApiSecret: e.target.value })}
          placeholder="Enter your WhatsApp API Secret"
        />
      </div>
      <Button type="submit" disabled={isSaving}>
        {isSaving ? "Saving..." : "Save Settings"}
      </Button>
    </form>
  );
}