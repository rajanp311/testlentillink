import React, { useState, useEffect } from "react";
import { Buyer } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Plus, Search, Phone, MapPin, Edit2, Trash2 } from "lucide-react";
import { format } from "date-fns";

import BuyerForm from "../components/buyers/BuyerForm";
import BuyerCard from "../components/buyers/BuyerCard";

export default function Buyers() {
  const [buyers, setBuyers] = useState([]);
  const [filteredBuyers, setFilteredBuyers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingBuyer, setEditingBuyer] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadBuyers();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      setFilteredBuyers(
        buyers.filter(buyer =>
          buyer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          buyer.business_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          buyer.phone.includes(searchTerm)
        )
      );
    } else {
      setFilteredBuyers(buyers);
    }
  }, [searchTerm, buyers]);

  const loadBuyers = async () => {
    try {
      const data = await Buyer.list("-created_date");
      setBuyers(data);
      setFilteredBuyers(data);
    } catch (error) {
      console.error("Error loading buyers:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (buyerData) => {
    try {
      if (editingBuyer) {
        await Buyer.update(editingBuyer.id, buyerData);
      } else {
        await Buyer.create(buyerData);
      }
      setShowForm(false);
      setEditingBuyer(null);
      loadBuyers();
    } catch (error) {
      console.error("Error saving buyer:", error);
    }
  };

  const handleEdit = (buyer) => {
    setEditingBuyer(buyer);
    setShowForm(true);
  };

  const handleDelete = async (buyerId) => {
    if (window.confirm("Are you sure you want to delete this buyer?")) {
      try {
        await Buyer.delete(buyerId);
        loadBuyers();
      } catch (error) {
        console.error("Error deleting buyer:", error);
      }
    }
  };

  const getStatusStats = () => {
    const stats = buyers.reduce((acc, buyer) => {
      acc[buyer.status] = (acc[buyer.status] || 0) + 1;
      return acc;
    }, {});
    return stats;
  };

  const statusStats = getStatusStats();

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-green-50 via-white to-emerald-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Buyer Management</h1>
            <p className="text-gray-600 mt-1">Manage your WhatsApp contacts and buyer information</p>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-green-600 hover:bg-green-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Buyer
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Buyers</p>
                  <p className="text-2xl font-bold text-gray-900">{buyers.length}</p>
                </div>
                <Users className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Buyers</p>
                  <p className="text-2xl font-bold text-green-600">{statusStats.active || 0}</p>
                </div>
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white/80 backdrop-blur-sm shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Inactive Buyers</p>
                  <p className="text-2xl font-bold text-orange-600">{statusStats.inactive || 0}</p>
                </div>
                <Badge className="bg-orange-100 text-orange-800">Inactive</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search Bar */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search buyers by name, business, or phone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Buyer Form */}
        {showForm && (
          <BuyerForm
            buyer={editingBuyer}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingBuyer(null);
            }}
          />
        )}

        {/* Buyers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                </CardContent>
              </Card>
            ))
          ) : filteredBuyers.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No buyers found</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? "Try adjusting your search terms" : "Start by adding your first buyer"}
              </p>
              <Button
                onClick={() => setShowForm(true)}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add First Buyer
              </Button>
            </div>
          ) : (
            filteredBuyers.map((buyer) => (
              <BuyerCard
                key={buyer.id}
                buyer={buyer}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}