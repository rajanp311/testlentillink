import React, { useState, useEffect } from "react";
import { LentilInventory } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Package, Plus, Search, AlertTriangle, TrendingUp, DollarSign } from "lucide-react";
import { format } from "date-fns";

import InventoryForm from "../components/inventory/InventoryForm";
import InventoryCard from "../components/inventory/InventoryCard";
import InventoryStats from "../components/inventory/InventoryStats";

const CONVERSION_RATES = {
    AED: 1,
    INR: 22.73,
    TRY: 8.88,
    USD: 0.27,
    KES: 35.25,
};

export default function Inventory() {
  const [inventory, setInventory] = useState([]);
  const [filteredInventory, setFilteredInventory] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filterGrade, setFilterGrade] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [displayCurrency, setDisplayCurrency] = useState("AED"); // New state

  useEffect(() => {
    loadInventory();
  }, []);

  useEffect(() => {
    let filtered = inventory;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.variety?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.origin?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply grade filter
    if (filterGrade !== "all") {
      filtered = filtered.filter(item => item.quality_grade === filterGrade);
    }

    // Apply sorting
    filtered = filtered.sort((a, b) => {
      switch (sortBy) {
        case "price":
          return b.current_price - a.current_price;
        case "stock":
          return b.stock_quantity - a.stock_quantity;
        case "name":
        default:
          return a.name.localeCompare(b.name);
      }
    });

    setFilteredInventory(filtered);
  }, [searchTerm, inventory, filterGrade, sortBy]);

  const loadInventory = async () => {
    try {
      const data = await LentilInventory.list("-updated_date");
      setInventory(data);
      setFilteredInventory(data);
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (itemData) => {
    try {
      const dataWithTimestamp = {
        ...itemData,
        last_updated: new Date().toISOString()
      };
      
      if (editingItem) {
        await LentilInventory.update(editingItem.id, dataWithTimestamp);
      } else {
        await LentilInventory.create(dataWithTimestamp);
      }
      setShowForm(false);
      setEditingItem(null);
      loadInventory();
    } catch (error) {
      console.error("Error saving inventory item:", error);
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setShowForm(true);
  };

  const handleDelete = async (itemId) => {
    if (window.confirm("Are you sure you want to delete this inventory item?")) {
      try {
        await LentilInventory.delete(itemId);
        loadInventory();
      } catch (error) {
        console.error("Error deleting inventory item:", error);
      }
    }
  };

  const getLowStockItems = () => {
    return inventory.filter(item => item.stock_quantity < 100);
  };

  const getTotalValue = () => {
    return inventory.reduce((total, item) => total + (item.current_price * item.stock_quantity), 0);
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-green-50 via-white to-emerald-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Lentil Inventory</h1>
            <p className="text-gray-600 mt-1">Manage your lentil stock and pricing</p>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-green-600 hover:bg-green-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Item
          </Button>
        </div>

        {/* Stats */}
        <InventoryStats 
          inventory={inventory}
          lowStockCount={getLowStockItems().length}
          totalValue={getTotalValue()}
        />

        {/* Filters and Search */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by name, variety, or origin..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2 flex-wrap"> {/* Added flex-wrap */}
                <Select value={displayCurrency} onValueChange={setDisplayCurrency}>
                  <SelectTrigger className="w-full md:w-[150px]">
                    <SelectValue placeholder="Currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.keys(CONVERSION_RATES).map(curr => (
                      <SelectItem key={curr} value={curr}>{curr}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filterGrade} onValueChange={setFilterGrade}>
                  <SelectTrigger className="w-full md:w-[150px]">
                    <SelectValue placeholder="Grade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Grades</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="basic">Basic</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full md:w-[150px]">
                        <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="name">Sort by Name</SelectItem>
                        <SelectItem value="price">Sort by Price</SelectItem>
                        <SelectItem value="stock">Sort by Stock</SelectItem>
                    </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Low Stock Alert */}
        {getLowStockItems().length > 0 && (
          <Card className="mb-6 border-orange-200 bg-orange-50/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-800">
                <AlertTriangle className="w-5 h-5" />
                Low Stock Alert ({getLowStockItems().length} items)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {getLowStockItems().slice(0, 6).map((item) => (
                  <div key={item.id} className="flex justify-between items-center p-3 bg-white rounded-lg border border-orange-200">
                    <div>
                      <span className="font-medium text-orange-900">{item.name}</span>
                      <p className="text-sm text-orange-700">{item.variety}</p>
                    </div>
                    <Badge className="bg-orange-100 text-orange-800">
                      {item.stock_quantity} {item.unit}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Inventory Form */}
        {showForm && (
          <InventoryForm
            item={editingItem}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingItem(null);
            }}
          />
        )}

        {/* Inventory Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                </CardContent>
              </Card>
            ))
          ) : filteredInventory.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No inventory items found</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? "Try adjusting your search terms" : "Start by adding your first inventory item"}
              </p>
              <Button
                onClick={() => setShowForm(true)}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add First Item
              </Button>
            </div>
          ) : (
            filteredInventory.map((item) => (
              <InventoryCard
                key={item.id}
                item={item}
                onEdit={handleEdit}
                onDelete={handleDelete}
                displayCurrency={displayCurrency}
                conversionRate={CONVERSION_RATES[displayCurrency]}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}