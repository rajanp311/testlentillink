import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Key, Bot } from "lucide-react";

import ApiConfiguration from "../components/settings/ApiConfiguration";
import OrderParser from "../components/settings/OrderParser";

export default function Settings() {
  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-green-50 via-white to-emerald-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600 mt-1">
            Configure your integrations and process incoming orders.
          </p>
        </div>

        <div className="space-y-8">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="w-5 h-5 text-gray-600" />
                <span>API Configuration</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ApiConfiguration />
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-gray-600" />
                <span>Parse Incoming Order</span>
              </CardTitle>
              <p className="text-sm text-gray-500 pt-1">
                Paste a raw message from WhatsApp to automatically extract and save order details.
              </p>
            </CardHeader>
            <CardContent>
              <OrderParser />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}