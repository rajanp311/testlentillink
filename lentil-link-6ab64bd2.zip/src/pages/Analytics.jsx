
import React, { useState, useEffect } from "react";
import { Campaign, Response, Buyer, LentilInventory } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { BarChart3, MessageSquare, Users, TrendingUp, Calendar, Package, DollarSign } from "lucide-react";
import { format, subDays, startOfDay, endOfDay } from "date-fns";

import MetricCard from "../components/analytics/MetricCard";
import ChartCard from "../components/analytics/ChartCard";

export default function Analytics() {
  const [campaigns, setCampaigns] = useState([]);
  const [responses, setResponses] = useState([]);
  const [buyers, setBuyers] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState("7");

  useEffect(() => {
    loadAnalyticsData();
  }, []);

  const loadAnalyticsData = async () => {
    try {
      const [campaignData, responseData, buyerData, inventoryData] = await Promise.all([
        Campaign.list(),
        Response.list("-response_date"),
        Buyer.list(),
        LentilInventory.list()
      ]);

      setCampaigns(campaignData);
      setResponses(responseData);
      setBuyers(buyerData);
      setInventory(inventoryData);
    } catch (error) {
      console.error("Error loading analytics data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getFilteredData = () => {
    const days = parseInt(timeRange);
    const cutoffDate = subDays(new Date(), days);
    
    return {
      responses: responses.filter(r => 
        r.response_date && new Date(r.response_date) >= cutoffDate
      ),
      campaigns: campaigns
    };
  };

  const getOverallMetrics = () => {
    const { responses: filteredResponses } = getFilteredData();
    const totalSent = campaigns.reduce((sum, c) => sum + (c.total_sent || 0), 0);
    const totalResponses = filteredResponses.length;
    const responseRate = totalSent > 0 ? (totalResponses / totalSent) * 100 : 0;
    const activeBuyers = buyers.filter(b => b.status === 'active').length;
    const totalInventoryValue = inventory.reduce((sum, item) => sum + (item.current_price * item.stock_quantity), 0);
    const averageOrderValue = filteredResponses.reduce((sum, r) => sum + (r.quoted_price || 0), 0) / (filteredResponses.length || 1);

    return {
      totalSent,
      totalResponses,
      responseRate: responseRate.toFixed(1),
      activeBuyers,
      totalInventoryValue,
      averageOrderValue,
      conversionRate: filteredResponses.filter(r => r.status === 'order_placed').length / (filteredResponses.length || 1) * 100
    };
  };

  const getResponsesByDay = () => {
    const { responses: filteredResponses } = getFilteredData();
    const days = parseInt(timeRange);
    const data = [];

    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dayStart = startOfDay(date);
      const dayEnd = endOfDay(date);
      
      const dayResponses = filteredResponses.filter(r => {
        const responseDate = new Date(r.response_date);
        return responseDate >= dayStart && responseDate <= dayEnd;
      });

      data.push({
        date: format(date, 'MMM d'),
        responses: dayResponses.length,
        orders: dayResponses.filter(r => r.status === 'order_placed').length
      });
    }

    return data;
  };

  const getCampaignPerformance = () => {
    return campaigns.map(campaign => ({
      name: campaign.name,
      sent: campaign.total_sent || 0,
      responses: campaign.total_responses || 0,
      rate: campaign.total_sent > 0 ? ((campaign.total_responses / campaign.total_sent) * 100).toFixed(1) : 0
    }));
  };

  const getResponseStatusDistribution = () => {
    const { responses: filteredResponses } = getFilteredData();
    const statusCounts = filteredResponses.reduce((acc, response) => {
      acc[response.status] = (acc[response.status] || 0) + 1;
      return acc;
    }, {});

    const colors = {
      pending: '#fbbf24',
      quoted: '#3b82f6',
      negotiating: '#8b5cf6',
      order_placed: '#10b981',
      declined: '#ef4444'
    };

    return Object.entries(statusCounts).map(([status, count]) => ({
      name: status.replace('_', ' ').toUpperCase(),
      value: count,
      color: colors[status] || '#6b7280'
    }));
  };

  const getTopLentilDemand = () => {
    const { responses: filteredResponses } = getFilteredData();
    const lentilDemand = {};

    filteredResponses.forEach(response => {
      if (response.requested_lentils) {
        response.requested_lentils.forEach(lentil => {
          lentilDemand[lentil.lentil_name] = (lentilDemand[lentil.lentil_name] || 0) + (lentil.quantity || 0);
        });
      }
    });

    return Object.entries(lentilDemand)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([name, quantity]) => ({ name, quantity }));
  };

  const metrics = getOverallMetrics();
  const responsesByDay = getResponsesByDay();
  const campaignPerformance = getCampaignPerformance();
  const statusDistribution = getResponseStatusDistribution();
  const topLentils = getTopLentilDemand();

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-green-50 via-white to-emerald-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
            <p className="text-gray-600 mt-1">Track your WhatsApp bot performance and business metrics</p>
          </div>
          <div className="flex items-center gap-3">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="14">Last 14 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Response Rate"
            value={`${metrics.responseRate}%`}
            icon={TrendingUp}
            color="green"
            trend="last 7 days"
          />
          <MetricCard
            title="Total Responses"
            value={metrics.totalResponses}
            icon={MessageSquare}
            color="blue"
            trend={`${timeRange} days`}
          />
          <MetricCard
            title="Active Buyers"
            value={metrics.activeBuyers}
            icon={Users}
            color="purple"
            trend="registered"
          />
          <MetricCard
            title="Conversion Rate"
            value={`${metrics.conversionRate.toFixed(1)}%`}
            icon={BarChart3}
            color="orange"
            trend="to orders"
          />
        </div>

        {/* Business Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <MetricCard
            title="Inventory Value"
            value={`AED ${metrics.totalInventoryValue.toLocaleString()}`}
            icon={Package}
            color="green"
            trend="total stock"
          />
          <MetricCard
            title="Average Order Value"
            value={`AED ${metrics.averageOrderValue.toLocaleString()}`}
            icon={DollarSign}
            color="blue"
            trend="per order"
          />
          <MetricCard
            title="Messages Sent"
            value={metrics.totalSent}
            icon={MessageSquare}
            color="purple"
            trend="all time"
          />
        </div>

        {/* Charts Grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Response Trend */}
          <ChartCard title="Response Trends" subtitle="Daily responses and orders">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={responsesByDay}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="responses" stroke="#3b82f6" strokeWidth={2} name="Responses" />
                <Line type="monotone" dataKey="orders" stroke="#10b981" strokeWidth={2} name="Orders" />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Campaign Performance */}
          <ChartCard title="Campaign Performance" subtitle="Response rates by campaign">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={campaignPerformance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="responses" fill="#3b82f6" name="Responses" />
                <Bar dataKey="rate" fill="#10b981" name="Response Rate %" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Response Status Distribution */}
          <ChartCard title="Response Status" subtitle="Distribution of response outcomes">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Top Lentil Demand */}
          <ChartCard title="Top Lentil Demand" subtitle="Most requested lentil types">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topLentils} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} />
                <Tooltip />
                <Bar dataKey="quantity" fill="#f59e0b" name="Quantity (kg)" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      </div>
    </div>
  );
}
