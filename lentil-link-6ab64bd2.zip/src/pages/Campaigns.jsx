import React, { useState, useEffect } from "react";
import { Campaign, Buyer } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { MessageSquare, Plus, Search, Play, Pause, Clock, Send } from "lucide-react";

import CampaignForm from "../components/campaigns/CampaignForm";
import CampaignCard from "../components/campaigns/CampaignCard";
import CampaignStats from "../components/campaigns/CampaignStats";

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState([]);
  const [buyers, setBuyers] = useState([]);
  const [filteredCampaigns, setFilteredCampaigns] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    let filtered = campaigns;

    if (searchTerm) {
      filtered = filtered.filter(campaign =>
        campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        campaign.message_template.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterStatus !== "all") {
      filtered = filtered.filter(campaign => campaign.status === filterStatus);
    }

    setFilteredCampaigns(filtered);
  }, [searchTerm, campaigns, filterStatus]);

  const loadData = async () => {
    try {
      const [campaignData, buyerData] = await Promise.all([
        Campaign.list("-created_date"),
        Buyer.list()
      ]);
      setCampaigns(campaignData);
      setBuyers(buyerData);
      setFilteredCampaigns(campaignData);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (campaignData) => {
    try {
      if (editingCampaign) {
        await Campaign.update(editingCampaign.id, campaignData);
      } else {
        await Campaign.create(campaignData);
      }
      setShowForm(false);
      setEditingCampaign(null);
      loadData();
    } catch (error) {
      console.error("Error saving campaign:", error);
    }
  };

  const handleEdit = (campaign) => {
    setEditingCampaign(campaign);
    setShowForm(true);
  };

  const handleDelete = async (campaignId) => {
    if (window.confirm("Are you sure you want to delete this campaign?")) {
      try {
        await Campaign.delete(campaignId);
        loadData();
      } catch (error) {
        console.error("Error deleting campaign:", error);
      }
    }
  };

  const handleStatusToggle = async (campaign) => {
    try {
      const newStatus = campaign.status === 'active' ? 'paused' : 'active';
      await Campaign.update(campaign.id, { ...campaign, status: newStatus });
      loadData();
    } catch (error) {
      console.error("Error updating campaign status:", error);
    }
  };

  const getStatusStats = () => {
    return campaigns.reduce((acc, campaign) => {
      acc[campaign.status] = (acc[campaign.status] || 0) + 1;
      return acc;
    }, {});
  };

  const getTotalStats = () => {
    return campaigns.reduce((acc, campaign) => {
      acc.totalSent += campaign.total_sent || 0;
      acc.totalResponses += campaign.total_responses || 0;
      return acc;
    }, { totalSent: 0, totalResponses: 0 });
  };

  const statusStats = getStatusStats();
  const totalStats = getTotalStats();

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-green-50 via-white to-emerald-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">WhatsApp Campaigns</h1>
            <p className="text-gray-600 mt-1">Create and manage your automated messaging campaigns</p>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-green-600 hover:bg-green-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Campaign
          </Button>
        </div>

        {/* Campaign Stats */}
        <CampaignStats
          campaigns={campaigns}
          statusStats={statusStats}
          totalStats={totalStats}
        />

        {/* Filters and Search */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search campaigns by name or message content..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border rounded-md bg-white"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="paused">Paused</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Integration Notice */}
        <Card className="mb-6 border-blue-200 bg-blue-50/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <MessageSquare className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-900">WhatsApp Integration Required</h3>
                <p className="text-sm text-blue-800 mt-1">
                  To send campaigns, you'll need to integrate with WhatsApp Business API. 
                  This system manages your campaign templates and schedules.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Form */}
        {showForm && (
          <CampaignForm
            campaign={editingCampaign}
            buyers={buyers}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingCampaign(null);
            }}
          />
        )}

        {/* Campaigns Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {isLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-4"></div>
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                </CardContent>
              </Card>
            ))
          ) : filteredCampaigns.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No campaigns found</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? "Try adjusting your search terms" : "Create your first WhatsApp campaign"}
              </p>
              <Button
                onClick={() => setShowForm(true)}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create First Campaign
              </Button>
            </div>
          ) : (
            filteredCampaigns.map((campaign) => (
              <CampaignCard
                key={campaign.id}
                campaign={campaign}
                buyers={buyers}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onStatusToggle={handleStatusToggle}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}