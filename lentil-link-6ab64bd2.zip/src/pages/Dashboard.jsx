import React, { useState, useEffect } from "react";
import { Buyer, LentilInventory, Campaign, Response } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Users, 
  Package, 
  MessageSquare, 
  TrendingUp, 
  Plus,
  Phone,
  Clock,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";

import StatsCard from "../components/dashboard/StatsCard";
import RecentActivity from "../components/dashboard/RecentActivity";
import QuickActions from "../components/dashboard/QuickActions";

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalBuyers: 0,
    activeBuyers: 0,
    totalInventory: 0,
    activeCampaigns: 0,
    todayMessages: 0,
    responseRate: 0
  });
  const [recentResponses, setRecentResponses] = useState([]);
  const [lowStockItems, setLowStockItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [buyers, inventory, campaigns, responses] = await Promise.all([
        Buyer.list(),
        LentilInventory.list(),
        Campaign.list(),
        Response.list('-response_date', 5)
      ]);

      const activeBuyers = buyers.filter(b => b.status === 'active').length;
      const activeCampaigns = campaigns.filter(c => c.status === 'active').length;
      const lowStock = inventory.filter(item => item.stock_quantity < 100);
      
      // Calculate today's messages and response rate
      const today = new Date().toISOString().split('T')[0];
      const todayResponses = responses.filter(r => 
        r.response_date && r.response_date.startsWith(today)
      );
      
      setStats({
        totalBuyers: buyers.length,
        activeBuyers,
        totalInventory: inventory.length,
        activeCampaigns,
        todayMessages: todayResponses.length,
        responseRate: buyers.length > 0 ? Math.round((todayResponses.length / buyers.length) * 100) : 0
      });

      setRecentResponses(responses);
      setLowStockItems(lowStock);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-8 bg-gradient-to-br from-green-50 via-white to-emerald-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">WhatsApp Bot Dashboard</h1>
            <p className="text-gray-600 mt-1">Manage your lentil trading bot and customer outreach</p>
          </div>
          <div className="flex gap-3">
            <Link to={createPageUrl("Campaigns")}>
              <Button className="bg-green-600 hover:bg-green-700 shadow-lg">
                <MessageSquare className="w-4 h-4 mr-2" />
                New Campaign
              </Button>
            </Link>
            <Link to={createPageUrl("Buyers")}>
              <Button variant="outline" className="border-green-200 hover:bg-green-50">
                <Users className="w-4 h-4 mr-2" />
                Add Buyer
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Active Buyers"
            value={stats.activeBuyers}
            total={stats.totalBuyers}
            icon={Users}
            color="green"
            trend="+5% this week"
          />
          <StatsCard
            title="Inventory Items"
            value={stats.totalInventory}
            icon={Package}
            color="blue"
            trend={`${lowStockItems.length} low stock`}
          />
          <StatsCard
            title="Active Campaigns"
            value={stats.activeCampaigns}
            icon={MessageSquare}
            color="purple"
          />
          <StatsCard
            title="Response Rate"
            value={`${stats.responseRate}%`}
            icon={TrendingUp}
            color="orange"
            trend="Today"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <RecentActivity responses={recentResponses} isLoading={isLoading} />
          </div>

          {/* Quick Actions & Alerts */}
          <div className="space-y-6">
            <QuickActions />
            
            {/* Low Stock Alert */}
            {lowStockItems.length > 0 && (
              <Card className="border-orange-200 bg-orange-50/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-orange-800">
                    <AlertCircle className="w-5 h-5" />
                    Low Stock Alert
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {lowStockItems.slice(0, 3).map((item) => (
                      <div key={item.id} className="flex justify-between items-center">
                        <span className="text-sm font-medium text-orange-900">{item.name}</span>
                        <Badge variant="outline" className="text-orange-700 border-orange-300">
                          {item.stock_quantity} {item.unit}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <Link to={createPageUrl("Inventory")}>
                    <Button variant="outline" size="sm" className="w-full mt-4 border-orange-300 hover:bg-orange-100">
                      View All Inventory
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}

            {/* System Status */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">System Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">WhatsApp Connection</span>
                    <Badge className="bg-orange-100 text-orange-800">Manual Setup Required</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Bot Status</span>
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Ready
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Last Sync</span>
                    <span className="text-sm text-gray-500">
                      {format(new Date(), 'MMM d, HH:mm')}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}